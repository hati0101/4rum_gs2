# 영향 범위 검토

기준196-5 SHA256 edd01371d6232f9add56357abc252b3a0f129c8e1e1318016207f41d074df127.
ESUI_SelectTraits 기존 호출자 ESUI_TraitKey/ESC_IconClick/ES15_Chat(-어스특성창), 신규 기존 E1964_Refresh에서 재선택. ESUI_Init의F8/OEM_3키업 등록과ESC_IconInit의기존IdleWorkerButton 이벤트 유지. 기존 ESUI_Enter/Leave 사거리 UI와 GSRI 키 입력 보존. 전체 함수 caller 그래프 policy.json/verification.json 참조.
E1966_IsController는기준맵w3u/skin에연구목록ures가있는n계열+udg_HeroSpeciel의유형을정적으로생성,총79종. n01M/n03J/nFl1/nE15/nSp1/nRat/nDr1/nSa1 변신/신규컨트롤러포함. 동기화된 ES15_Tick에서0.25초간격유효성검사,이미유효한캐시는재열거하지않음. 영웅변경/컨트롤러제거/소유자변경때공유group하나로ownedunits열거후정확히1개인경우캐시. 캐시검사/열거에GetLocalPlayer사용없음. UI선택함수는캐시/동기화된상태를읽고로컬선택만변경,로컬핸들생성없음. 게임판정이pending/로컬선택에의존하지않음. 새로운커스텀BUTTON없음. ES15_Init에서group1개전역생성;새타이머없음. 미존재캐시는최대0.25초후갱신.
RE13추가효과는E1966_AmrStats에서ES15_Data[heroHandle,430]boolean으로상태전환을기록. ETW_TooltipRefresh의기존마스크조기반환보다앞/로컬분기보다앞에서호출. HE15비환영만허용. SetHeroStr(base±10,true),BlzSetUnitMaxHP(currentMax±200),스탯/레벨/아이템다른증분보존. 현재체력/마나를직접설정하지않음. 실제엔진에서힘체력변화/사망부활의표시·지속성은별도검증필요. 특성켜기/끄기모사10회순환정확히원복,보유중수준/아이템증가량보존모사. 레거시전투모사는새UI스캔/능력치동기화호출을mock하고새전용모사에서실제함수본문실행;엔진의체력상속그자체를증명하지않음.
런타임/WCT각변경함수동일확인. JASS선언순서에맞춰ESUI_SelectTraits앞으로이동. 첫두빌드는미선언함수문법검사실패로차단되어배포하지않음;최종-c빌드PASS만배포. 기준원본보존,후보백업/추출인벤토리/gate상세는artifact빌드디렉터리.
