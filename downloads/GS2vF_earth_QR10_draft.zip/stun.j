function ESQ4_Stun takes unit h, unit v returns nothing
    local unit dummy
    if not ES15_Alive(v) or IsUnitType(v,UNIT_TYPE_MAGIC_IMMUNE) then
        return
    endif
    set dummy=CreateUnit(GetOwningPlayer(h),'ewsp',GetUnitX(v),GetUnitY(v),0)
    call UnitAddAbility(dummy,'Aloc')
    call UnitAddAbility(dummy,'AEs4')
    call IssueTargetOrder(dummy,"thunderbolt",v)
    call UnitApplyTimedLife(dummy,'BTLF',1.5)
    set dummy=null
endfunction
