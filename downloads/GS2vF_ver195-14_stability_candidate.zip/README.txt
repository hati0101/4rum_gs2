195-14 stability candidate. Based on user 195-13. Not validated in Warcraft multiplayer.
SHA256: ca0baba870779dc39529a5425efba52034e4f7944703bad76e352aeb302f26b0
