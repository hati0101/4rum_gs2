// Modify the existing physical attack before armor; never emit a second hit.
function ESW5_Attack takes nothing returns nothing
    local unit h=GetEventDamageSource()
    local unit v=GetTriggerUnit()
    local integer lv
    if GetUnitTypeId(h)=='HE15' and ES15_RealHero(h) and ES15_Alive(v) and IsUnitEnemy(v,GetOwningPlayer(h)) and not IsUnitType(v,UNIT_TYPE_STRUCTURE) and BlzGetEventIsAttack() and BlzGetEventDamageType()==DAMAGE_TYPE_NORMAL and GetEventDamage()>0.0 and LoadReal(ES15_Data,GetHandleId(h),10)>ES15_Now() then
        set lv=GetUnitAbilityLevel(h,'AE1w')
        if lv>=1 and lv<=4 then
            call BlzSetEventDamage(GetEventDamage()+10.0+10.0*I2R(lv))
        endif
    endif
    set h=null
    set v=null
endfunction
