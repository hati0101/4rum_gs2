// Effects only: these functions never deal damage, issue orders, or change stats.
function ES16_Z takes real x, real y returns real
    call MoveLocation(ES16_Ground,x,y)
    return GetLocationZ(ES16_Ground)
endfunction
function ES16_QTick takes nothing returns nothing
    local timer t=GetExpiredTimer()
    local integer k=GetHandleId(t)
    local integer step=LoadInteger(ES16_Fx,k,3)+1
    local integer i=0
    local real angle=LoadReal(ES16_Fx,k,2)
    local real yaw
    local real distance=40.0+28.5*I2R(step)
    local real x
    local real y
    local effect e
    loop
        exitwhen i>=5
        set yaw=angle-0.7853981634+0.3926990817*I2R(i)
        set x=LoadReal(ES16_Fx,k,0)+distance*Cos(yaw)
        set y=LoadReal(ES16_Fx,k,1)+distance*Sin(yaw)
        set e=LoadEffectHandle(ES16_Fx,k,10+i)
        if e!=null then
            call BlzSetSpecialEffectPosition(e,x,y,ES16_Z(x,y)+45.0)
        endif
        if step>=10 and e!=null then
            call DestroyEffect(e)
        endif
        set i=i+1
    endloop
    if step>=10 then
        call PauseTimer(t)
        call DestroyTimer(t)
        call FlushChildHashtable(ES16_Fx,k)
    else
        call SaveInteger(ES16_Fx,k,3,step)
    endif
    set e=null
    set t=null
endfunction
function ES16_QVisual takes unit h, real angle returns nothing
    local timer t=CreateTimer()
    local integer k=GetHandleId(t)
    local integer i=0
    local real yaw
    local real x
    local real y
    local effect e
    call SetUnitAnimation(h,"attack")
    call QueueUnitAnimation(h,"stand")
    call SaveReal(ES16_Fx,k,0,GetUnitX(h))
    call SaveReal(ES16_Fx,k,1,GetUnitY(h))
    call SaveReal(ES16_Fx,k,2,angle)
    call SaveInteger(ES16_Fx,k,3,0)
    loop
        exitwhen i>=5
        set yaw=angle-0.7853981634+0.3926990817*I2R(i)
        set x=GetUnitX(h)+40.0*Cos(yaw)
        set y=GetUnitY(h)+40.0*Sin(yaw)
        set e=AddSpecialEffect("Abilities\\Weapons\\AncientProtectorMissile\\AncientProtectorMissile.mdl",x,y)
        call BlzSetSpecialEffectScale(e,0.55)
        call BlzSetSpecialEffectYaw(e,yaw)
        call BlzSetSpecialEffectPosition(e,x,y,ES16_Z(x,y)+45.0)
        call SaveEffectHandle(ES16_Fx,k,10+i,e)
        set i=i+1
    endloop
    call TimerStart(t,0.03125,true,function ES16_QTick)
    set e=null
    set t=null
endfunction
function ES16_WEnd takes unit h returns nothing
    local integer k=GetHandleId(h)
    local integer i=0
    local effect e
    loop
        exitwhen i>=3
        set e=LoadEffectHandle(ES16_Fx,k,100+i)
        if e!=null then
            call BlzSetSpecialEffectScale(e,0.0)
            call DestroyEffect(e)
            call RemoveSavedHandle(ES16_Fx,k,100+i)
        endif
        set i=i+1
    endloop
    call GroupRemoveUnit(ES16_WUnits,h)
    set e=null
endfunction
function ES16_WVisual takes unit h returns nothing
    local integer k=GetHandleId(h)
    local integer i=0
    local effect e
    call ES16_WEnd(h)
    loop
        exitwhen i>=3
        set e=AddSpecialEffect("Abilities\\Weapons\\AncientProtectorMissile\\AncientProtectorMissile.mdl",GetUnitX(h),GetUnitY(h))
        call BlzSetSpecialEffectScale(e,0.45)
        call SaveEffectHandle(ES16_Fx,k,100+i,e)
        set i=i+1
    endloop
    call GroupAddUnit(ES16_WUnits,h)
    set e=null
endfunction
function ES16_WTick takes nothing returns nothing
    local integer n=BlzGroupGetSize(ES16_WUnits)-1
    local integer i
    local integer k
    local unit h
    local real now=ES15_Now()
    local real yaw
    local real x
    local real y
    local real ground
    local effect e
    loop
        exitwhen n<0
        set h=BlzGroupUnitAt(ES16_WUnits,n)
        set k=GetHandleId(h)
        if not ES15_Alive(h) or LoadReal(ES15_Data,k,10)<=now then
            call ES16_WEnd(h)
        else
            set i=0
            set ground=ES16_Z(GetUnitX(h),GetUnitY(h))
            loop
                exitwhen i>=3
                set yaw=now*2.4+I2R(i)*2.0943951024
                set x=GetUnitX(h)+75.0*Cos(yaw)
                set y=GetUnitY(h)+75.0*Sin(yaw)
                set e=LoadEffectHandle(ES16_Fx,k,100+i)
                if e!=null then
                    call BlzSetSpecialEffectPosition(e,x,y,ground+65.0+15.0*Sin(yaw))
                    call BlzSetSpecialEffectYaw(e,yaw)
                endif
                set i=i+1
            endloop
        endif
        set n=n-1
    endloop
    set e=null
    set h=null
endfunction
function ES16_Init takes nothing returns nothing
    set ES16_Fx=InitHashtable()
    set ES16_WUnits=CreateGroup()
    set ES16_Ground=Location(0,0)
    call TimerStart(CreateTimer(),0.03125,true,function ES16_WTick)
endfunction
