function ESR6_End takes unit h returns nothing
    local integer k=GetHandleId(h)
    local integer i=0
    local effect e
    loop
        exitwhen i>=6
        set e=LoadEffectHandle(ES16_Fx,k,200+i)
        if e!=null then
            call BlzSetSpecialEffectScale(e,0.0)
            call DestroyEffect(e)
            call RemoveSavedHandle(ES16_Fx,k,200+i)
        endif
        set i=i+1
    endloop
    set e=null
endfunction
function ESR6_Position takes unit h, real now returns nothing
    local integer k=GetHandleId(h)
    local integer i=0
    local real yaw
    local real ground=ES16_Z(GetUnitX(h),GetUnitY(h))
    local effect e
    loop
        exitwhen i>=6
        set e=LoadEffectHandle(ES16_Fx,k,200+i)
        if e!=null then
            set yaw=now*0.8+I2R(i)*1.0471975512
            call BlzSetSpecialEffectPosition(e,GetUnitX(h)+120.0*Cos(yaw),GetUnitY(h)+120.0*Sin(yaw),ground+80.0+10.0*Sin(yaw))
            call BlzSetSpecialEffectYaw(e,yaw)
        endif
        set i=i+1
    endloop
    set e=null
endfunction
function ESR6_Start takes unit h returns nothing
    local integer k=GetHandleId(h)
    local integer i=0
    local effect e
    call ESR6_End(h)
    loop
        exitwhen i>=6
        set e=AddSpecialEffect("Abilities\\Weapons\\AncientProtectorMissile\\AncientProtectorMissile.mdl",GetUnitX(h),GetUnitY(h))
        if e!=null then
            call BlzSetSpecialEffectScale(e,0.70)
            call SaveEffectHandle(ES16_Fx,k,200+i,e)
        endif
        set i=i+1
    endloop
    call ESR6_Position(h,ES15_Now())
    set e=null
endfunction
function ESR6_Tick takes nothing returns nothing
    local real now=ES15_Now()
    local integer i
    local integer k
    local unit h
    if LoadReal(ES16_Fx,0,301)>now then
        return
    endif
    call SaveReal(ES16_Fx,0,301,now+0.0625)
    set i=BlzGroupGetSize(ES15_Shields)-1
    loop
        exitwhen i<0
        set h=BlzGroupUnitAt(ES15_Shields,i)
        set k=GetHandleId(h)
        if not ES15_Alive(h) or LoadReal(ES15_Data,k,20)<=0.0 or LoadReal(ES15_Data,k,21)<=now then
            call ESR6_End(h)
        else
            call ESR6_Position(h,now)
        endif
        set i=i-1
    endloop
    set h=null
endfunction
