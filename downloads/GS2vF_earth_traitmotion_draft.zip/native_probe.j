function ETW_ProbeDistance takes integer k returns real
    local unit u=LoadUnitHandle(ES15_Data,k,0)
    local real dx=GetUnitX(u)-LoadReal(ES15_Data,k,30)
    local real dy=GetUnitY(u)-LoadReal(ES15_Data,k,31)
    set u=null
    return SquareRoot(dx*dx+dy*dy)
endfunction
function ETW_ProbeReset takes integer k returns nothing
    local unit u=LoadUnitHandle(ES15_Data,k,0)
    call SetUnitPosition(u,LoadReal(ES15_Data,k,4),LoadReal(ES15_Data,k,5))
    call SetUnitFacing(u,0.0)
    call SaveReal(ES15_Data,k,30,GetUnitX(u))
    call SaveReal(ES15_Data,k,31,GetUnitY(u))
    set u=null
endfunction
function ETW_ProbeMove takes integer k returns nothing
    local unit u=LoadUnitHandle(ES15_Data,k,0)
    call SaveReal(ES15_Data,k,30,GetUnitX(u))
    call SaveReal(ES15_Data,k,31,GetUnitY(u))
    call IssuePointOrder(u,"move",LoadReal(ES15_Data,k,4)+512.0,LoadReal(ES15_Data,k,5))
    set u=null
endfunction
function ETW_ProbeBool takes boolean value returns string
    if value then
        return "1"
    endif
    return "0"
endfunction
function ETW_ProbeEnd takes timer t returns nothing
    local integer k=GetHandleId(t)
    local player p=LoadPlayerHandle(ES15_Data,k,2)
    local unit u=LoadUnitHandle(ES15_Data,k,0)
    local unit d=LoadUnitHandle(ES15_Data,k,1)
    if LoadTimerHandle(ES15_Data,0,200+GetPlayerId(p))==t then
        call RemoveSavedHandle(ES15_Data,0,200+GetPlayerId(p))
    endif
    call RemoveUnit(u)
    call RemoveUnit(d)
    call FlushChildHashtable(ES15_Data,k)
    call DestroyTimer(t)
    set p=null
    set u=null
    set d=null
endfunction
function ETW_ProbeTick takes nothing returns nothing
    local timer t=GetExpiredTimer()
    local integer k=GetHandleId(t)
    local integer stage=LoadInteger(ES15_Data,k,3)
    local unit u=LoadUnitHandle(ES15_Data,k,0)
    local unit d=LoadUnitHandle(ES15_Data,k,1)
    local player p=LoadPlayerHandle(ES15_Data,k,2)
    local ability a
    local real delay=0.40
    if GetUnitTypeId(u)==0 or GetUnitTypeId(d)==0 or GetWidgetLife(u)<=0.405 then
        call DisplayTimedTextToPlayer(p,0,0,30,"[W진단] 진단 유닛이 사라져 중단했습니다.")
        call ETW_ProbeEnd(t)
    else
        if stage==0 then
            call SaveReal(ES15_Data,k,6,ETW_ProbeDistance(k))
            call SaveReal(ES15_Data,k,22,GetUnitMoveSpeed(u))
            call ETW_ProbeReset(k)
            call IssueTargetOrder(d,"cripple",u)
            set delay=0.20
        elseif stage==1 then
            call SaveBoolean(ES15_Data,k,18,GetUnitAbilityLevel(u,'BTwD')>0)
            call SaveReal(ES15_Data,k,11,GetUnitMoveSpeed(u))
            call SaveReal(ES15_Data,k,12,BlzGetUnitRealField(u,UNIT_RF_SPEED))
            call ETW_ProbeMove(k)
        elseif stage==2 then
            call SaveReal(ES15_Data,k,7,ETW_ProbeDistance(k))
            call ETW_ProbeReset(k)
            call SetUnitMoveSpeed(u,GetUnitDefaultMoveSpeed(u))
            call ETW_ProbeMove(k)
        elseif stage==3 then
            call SaveReal(ES15_Data,k,8,ETW_ProbeDistance(k))
            call ETW_ProbeReset(k)
            set a=BlzGetUnitAbility(u,'BTwD')
            call SaveBoolean(ES15_Data,k,23,a!=null)
            if a!=null then
                call SaveReal(ES15_Data,k,13,BlzGetAbilityRealLevelField(a,ABILITY_RLF_MOVEMENT_SPEED_REDUCTION_PERCENT_CRI1,0))
                call SaveReal(ES15_Data,k,14,BlzGetAbilityRealLevelField(a,ABILITY_RLF_ATTACK_SPEED_REDUCTION_PERCENT_CRI2,0))
                call SaveReal(ES15_Data,k,15,BlzGetAbilityRealLevelField(a,ABILITY_RLF_DAMAGE_REDUCTION_CRI3,0))
                call SaveBoolean(ES15_Data,k,16,BlzSetAbilityRealLevelField(a,ABILITY_RLF_MOVEMENT_SPEED_REDUCTION_PERCENT_CRI1,0,0.0))
                call BlzUnitDisableAbility(u,'BTwD',true,false)
                call BlzUnitDisableAbility(u,'BTwD',false,false)
            endif
            call ETW_ProbeMove(k)
        elseif stage==4 then
            call SaveReal(ES15_Data,k,9,ETW_ProbeDistance(k))
            call SaveBoolean(ES15_Data,k,19,GetUnitAbilityLevel(u,'BTwD')>0)
            set a=BlzGetUnitAbility(u,'BTwD')
            if a!=null then
                call SaveReal(ES15_Data,k,24,BlzGetAbilityRealLevelField(a,ABILITY_RLF_ATTACK_SPEED_REDUCTION_PERCENT_CRI2,0))
                call SaveReal(ES15_Data,k,25,BlzGetAbilityRealLevelField(a,ABILITY_RLF_DAMAGE_REDUCTION_CRI3,0))
            endif
            call ETW_ProbeReset(k)
            // Reset only the isolated diagnostic debuff, never a player's buff.
            call UnitRemoveAbility(u,'BTwD')
            call IssueTargetOrder(d,"cripple",u)
            set delay=0.20
        elseif stage==5 then
            call IssueImmediateOrder(u,"berserk")
            set delay=0.20
        elseif stage==6 then
            call SaveBoolean(ES15_Data,k,17,GetUnitAbilityLevel(u,'BTwC')>0)
            call SaveReal(ES15_Data,k,20,GetUnitMoveSpeed(u))
            call ETW_ProbeMove(k)
        else
            call SaveReal(ES15_Data,k,10,ETW_ProbeDistance(k))
            call DisplayTimedTextToPlayer(p,0,0,90,"[W진단1] 이동거리: 기본="+R2SW(LoadReal(ES15_Data,k,6),0,1)+" 감속="+R2SW(LoadReal(ES15_Data,k,7),0,1)+" SetMS="+R2SW(LoadReal(ES15_Data,k,8),0,1)+" Buff0="+R2SW(LoadReal(ES15_Data,k,9),0,1)+" 보정="+R2SW(LoadReal(ES15_Data,k,10),0,1))
            call DisplayTimedTextToPlayer(p,0,0,90,"[W진단2] GetMS 기본/감속/보정="+R2SW(LoadReal(ES15_Data,k,22),0,1)+"/"+R2SW(LoadReal(ES15_Data,k,11),0,1)+"/"+R2SW(LoadReal(ES15_Data,k,20),0,1)+" UnitRF="+R2SW(LoadReal(ES15_Data,k,12),0,1))
            call DisplayTimedTextToPlayer(p,0,0,90,"[W진단3] 감속적용="+ETW_ProbeBool(LoadBoolean(ES15_Data,k,18))+" 버프핸들="+ETW_ProbeBool(LoadBoolean(ES15_Data,k,23))+" 성분설정="+ETW_ProbeBool(LoadBoolean(ES15_Data,k,16))+" 버프유지="+ETW_ProbeBool(LoadBoolean(ES15_Data,k,19))+" 보정버프="+ETW_ProbeBool(LoadBoolean(ES15_Data,k,17)))
            call DisplayTimedTextToPlayer(p,0,0,90,"[W진단4] 성분 MS/AS/공격감소="+R2SW(LoadReal(ES15_Data,k,13),0,2)+"/"+R2SW(LoadReal(ES15_Data,k,14),0,2)+"/"+R2SW(LoadReal(ES15_Data,k,15),0,2)+" 설정후 AS/공격감소="+R2SW(LoadReal(ES15_Data,k,24),0,2)+"/"+R2SW(LoadReal(ES15_Data,k,25),0,2))
            if LoadReal(ES15_Data,k,6)<10.0 or not LoadBoolean(ES15_Data,k,18) then
                call DisplayTimedTextToPlayer(p,0,0,90,"[W진단] 경로 또는 감속 적용 실패. 넓은 직선 지형에서 다시 실행해야 합니다.")
            endif
            call ETW_ProbeEnd(t)
        endif
        if stage<7 then
            call SaveInteger(ES15_Data,k,3,stage+1)
            call TimerStart(t,delay,false,function ETW_ProbeTick)
        endif
    endif
    set a=null
    set u=null
    set d=null
    set p=null
    set t=null
endfunction
function ETW_ProbeStart takes player p, unit h returns nothing
    local real x=GetUnitX(h)+160.0
    local real y=GetUnitY(h)+96.0
    local timer t
    local integer k
    local unit u
    local unit d
    if LoadTimerHandle(ES15_Data,0,200+GetPlayerId(p))!=null then
        call DisplayTimedTextToPlayer(p,0,0,10,"[W진단] 이미 검사 중입니다.")
        return
    endif
    if x+576.0>GetRectMaxX(bj_mapInitialPlayableArea) then
        set x=GetUnitX(h)-672.0
    endif
    if x<GetRectMinX(bj_mapInitialPlayableArea)+64.0 or y>GetRectMaxY(bj_mapInitialPlayableArea)-64.0 or IsTerrainPathable(x,y,PATHING_TYPE_WALKABILITY) or IsTerrainPathable(x+256.0,y,PATHING_TYPE_WALKABILITY) or IsTerrainPathable(x+512.0,y,PATHING_TYPE_WALKABILITY) then
        call DisplayTimedTextToPlayer(p,0,0,20,"[W진단] 오른쪽으로 넓은 직선 공간이 있는 곳에서 실행하세요.")
        return
    endif
    set t=CreateTimer()
    set k=GetHandleId(t)
    set u=CreateUnit(Player(PLAYER_NEUTRAL_PASSIVE),'hfoo',x,y,0.0)
    set d=CreateUnit(Player(PLAYER_NEUTRAL_PASSIVE),'ewsp',x,y+64.0,0.0)
    call SetUnitAcquireRange(u,0.0)
    call BlzSetUnitMaxHP(u,100000)
    call SetWidgetLife(u,100000.0)
    call UnitAddAbility(d,'Aloc')
    call UnitAddAbility(d,'ATwD')
    call UnitAddAbility(u,'ATwC')
    call SaveUnitHandle(ES15_Data,k,0,u)
    call SaveUnitHandle(ES15_Data,k,1,d)
    call SavePlayerHandle(ES15_Data,k,2,p)
    call SaveReal(ES15_Data,k,4,GetUnitX(u))
    call SaveReal(ES15_Data,k,5,GetUnitY(u))
    call SaveTimerHandle(ES15_Data,0,200+GetPlayerId(p),t)
    call DisplayTimedTextToPlayer(p,0,0,20,"[W진단] 별도 유닛으로 감속 성분을 검사합니다. 약 3초 후 결과4줄을 출력합니다. 영웅/아이템/특성은 변경하지 않습니다.")
    call ETW_ProbeMove(k)
    call TimerStart(t,0.40,false,function ETW_ProbeTick)
    set u=null
    set d=null
    set t=null
endfunction
