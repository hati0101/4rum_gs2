function ETW_TooltipInit takes nothing returns nothing
    local integer i=0
    loop
        exitwhen i>=4
        call SaveStr(ES15_Data,'AE1q',300+i,BlzGetAbilityExtendedTooltip('AE1q',i))
        call SaveStr(ES15_Data,'AE1w',300+i,BlzGetAbilityExtendedTooltip('AE1w',i))
        call SaveStr(ES15_Data,'AE1e',300+i,BlzGetAbilityExtendedTooltip('AE1e',i))
        if i<3 then
            call SaveStr(ES15_Data,'AE1r',300+i,BlzGetAbilityExtendedTooltip('AE1r',i))
        endif
        set i=i+1
    endloop
endfunction
function ETW_TooltipRefresh takes unit h returns nothing
    local integer k=GetHandleId(h)
    local player p=GetOwningPlayer(h)
    local integer i=1
    local integer mask=0
    local integer bit=1
    if GetUnitTypeId(h)!='HE15' then
        set p=null
        return
    endif
    loop
        exitwhen i>5
        if ES15_Trait(h,i) then
            set mask=mask+bit
        endif
        set bit=bit*2
        set i=i+1
    endloop
    if HaveSavedInteger(ES15_Data,k,173) and LoadInteger(ES15_Data,k,173)==mask then
        set p=null
        return
    endif
    call SaveInteger(ES15_Data,k,173,mask)
    // Only tooltip setters are local. Research and cache-mask decisions sync.
    if GetLocalPlayer()==p then
        set i=0
        loop
            exitwhen i>=4
            call BlzSetAbilityExtendedTooltip('AE1q',LoadStr(ES15_Data,'AE1q',300+i),i)
            call BlzSetAbilityExtendedTooltip('AE1w',LoadStr(ES15_Data,'AE1w',300+i),i)
            call BlzSetAbilityExtendedTooltip('AE1e',LoadStr(ES15_Data,'AE1e',300+i),i)
            if i<3 then
                call BlzSetAbilityExtendedTooltip('AE1r',LoadStr(ES15_Data,'AE1r',300+i),i)
            endif
            set i=i+1
        endloop
        // NUMERIC_TRAIT_TOOLTIPS
    endif
    if ES15_Trait(h,1) then
        call GS2TT_Append(p,'AE1q',4,"깎아낸 바위","석갑 소모 시 감속 +10%p · 지속 +0.5초",true)
    endif
    if ES15_Trait(h,2) then
        call GS2TT_Append(p,'AE1w',4,"깊은 뿌리","지원 감속 해제 · 1.5초 면역 / 복합 감속 미완료",true)
    endif
    if ES15_Trait(h,3) then
        call GS2TT_Append(p,'AE1e',4,"겹겹의 암반","석갑 최대 12개 · 개당 방어력 유지",true)
    endif
    if ES15_Trait(h,4) then
        call GS2TT_Append(p,'AE1r',3,"대지의 성역","보호막 대상 방어력 +3 · 보호막 소진/종료 시 해제",true)
    endif
    if ES15_Trait(h,5) then
        call GS2TT_Append(p,'AE1q',4,"지맥 순환","적 영웅 적중 시 소모 석갑당 체력8·마나3 회복 · 시전당 1회",true)
    endif
    set p=null
endfunction
function ETW_Research takes nothing returns nothing
    local unit controller=GetTriggerUnit()
    local player p=GetOwningPlayer(controller)
    local unit h=udg_HeroPlayer[GetPlayerId(p)+1]
    if GetUnitTypeId(controller)=='nE15' then
        call ETW_TooltipRefresh(h)
    endif
    set controller=null
    set p=null
    set h=null
endfunction
