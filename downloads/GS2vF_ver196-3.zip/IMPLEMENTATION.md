# 구현 범위

기준196-2 SHA256 27a191e51f27ae134d392f7b37b41d9862d68561b1acf36bffddb486999aef6b.
런타임 Trig_Blood_Strike_DM_Actions의 미사용 GetUnitLoc1줄/RemoveLocation4줄 제거. 전역 변수 선언은 보존. WTG는 SetVariable/RemoveLocation ECA5개의 enabled 정수1→0만 변경, 길이/다른 바이트 보존. 해당GUI생성함수는WCT에원래없으므로WTG를별도정리함. F9안내는ES15_Init의정상1회초기화에선택퀘스트1개추가,동일함수WCT복사본반영. 다른변경함수는버전문구196-2→196-3뿐.
내부변경파일은war3map.j/wct/wtg/w3i/attributes. 모든w3a/w3q/w3u/w3t/스킨/리소스동일. 재패키징도달불가공간만정리. 전체활성1069파일보존.

재현:
python3 reviews/ver196-3/build.py /tmp/gs2-ver196-3-new
python3 reviews/ver196-3/probe.py /tmp/gs2-ver196-3-new/GS2vF_ver196-3.w3x
python3 -m unittest discover -s tests/harness -v

실게임확인: 치우E각레벨라인평타/피해회복확률유지, F9히든4조건표시, 돌노부196-2기능유지. 모두아직미실행. PolledWait/전역타겟/공통피해분배기동작은수정하지않았다. 전원멈춤해결검증은별도필요.
