# 196-4 구현 및 검토

직접 기준196-3 SHA256 6c83ac964e10bf8b608f06b9b5217b7cafb7e34f4fea660e47817018f5e4f3bb.
추가 변경 함수: ESC_IconClick, ESC_IconInit, GSRI_Tick, 신규E1964_Refresh. 기타함수차이는버전문구뿐. GSRI_Tick의기존WCT복사본에는이미런타임과다른구간이있었으며그차이를보존하고양쪽모두Refresh호출만삽입했다. ESC_IconClick/Init/Refresh는WCT와런타임일치.
UI투명BUTTON은한번전역초기화하며native IdleWorkerButton의bounds를재사용. 프레임이늦게생기면기존UI틱에서조회/앵커만갱신하고추가핸들을만들지않음. native프레임이끝내없으면overlay를숨김. 프레임가시성·pending·선택은로컬UI에만쓰며전투데이터에읽지않음. 신규반복타이머없음. 클릭보정에로컬타이머·유닛을생성하지않음. 소유자/hero/controller타입검사로다른사람컨트롤러선택방지. 기본F8/백틱함수보존.
HE15 uinp값1.5의type1→2만교정,raw객체파일1바이트차이확인. 참고메타데이터 /workspace/gs2-war3-data/data/zhCN-1.24.4/mpq/units/UnitMetaData.slk의uinp/INTplus/type unreal과다른성장필드type2를근거로함. 해당참고데이터는현재설치된3.0.1기본데이터가아니므로실제native성장검증과구분. 덧셈스크립트없어정상상속시중복성장없음.
196-3의치우런타임·WTG누수정리/F9안내유지. 직접기준대비변경내부파일j/wct/w3i/w3u/attributes. wtg/w3a/w3q/w3t/스킨/자산은196-3과바이트동일.

재현:
python3 reviews/ver196-4/build.py /tmp/gs2-ver196-4-new
python3 reviews/ver196-4/probe.py /tmp/gs2-ver196-4-new/GS2vF_ver196-4.w3x

실제확인항목:메달클릭/F8/백틱전환반복및화면해상도별아이콘겹침,돌노부여러레벨지능변화/장비와속성보너스분리확인,F9네히든안내,치우라인평타와E미발동장기누적. 전원멈춤재현은별도조사. 어떤항목도실제로성공했다고보고하지않음.
