function EAV_End takes unit h returns nothing
    local integer k=GetHandleId(h)
    local timer t=LoadTimerHandle(ES15_Data,k,223)
    if t!=null then
        call PauseTimer(t)
        call FlushChildHashtable(ES15_Data,GetHandleId(t))
        call DestroyTimer(t)
        call RemoveSavedHandle(ES15_Data,k,223)
    endif
    if LoadBoolean(ES15_Data,k,222) then
        if GetUnitTypeId(h)!=0 then
            call UnitRemoveAbility(h,'EWav')
        endif
        call RemoveSavedBoolean(ES15_Data,k,222)
        call RemoveSavedReal(ES15_Data,k,12)
    endif
    set t=null
endfunction
function EAV_Expire takes nothing returns nothing
    local timer t=GetExpiredTimer()
    local integer tk=GetHandleId(t)
    local unit h=LoadUnitHandle(ES15_Data,tk,0)
    if LoadTimerHandle(ES15_Data,GetHandleId(h),223)==t then
        call RemoveSavedHandle(ES15_Data,GetHandleId(h),223)
        call EAV_End(h)
    endif
    call FlushChildHashtable(ES15_Data,tk)
    call DestroyTimer(t)
    set h=null
    set t=null
endfunction
function EAV_Tick takes unit h returns nothing
    if LoadBoolean(ES15_Data,GetHandleId(h),222) then
        if GetUnitTypeId(h)!='HE15' or not ES15_Alive(h) then
            call EAV_End(h)
        endif
    endif
endfunction
function EAV_Start takes unit h returns nothing
    local integer k=GetHandleId(h)
    local timer t=LoadTimerHandle(ES15_Data,k,223)
    if GetUnitTypeId(h)!='HE15' or not ES15_Alive(h) then
        return
    endif
    call UnitAddAbility(h,'EWav')
    if GetUnitAbilityLevel(h,'EWav')<=0 then
        return
    endif
    if t!=null then
        call PauseTimer(t)
        call FlushChildHashtable(ES15_Data,GetHandleId(t))
        call DestroyTimer(t)
    endif
    call SaveBoolean(ES15_Data,k,222,true)
    call SaveReal(ES15_Data,k,12,ES15_Now()+1.5)
    call BlzUnitHideAbility(h,'EWav',true)
    // Negative magic only; positive buffs and other immunity sources stay.
    call UnitRemoveBuffsEx(h,false,true,true,false,false,false,false)
    // Shinobu's acid-bomb-based bottle is not handled by every dispel filter.
    call UnitRemoveAbility(h,'B04T')
    call DestroyEffect(AddSpecialEffectTarget("Abilities\\Spells\\Human\\Avatar\\AvatarCaster.mdl",h,"origin"))
    set t=CreateTimer()
    call SaveUnitHandle(ES15_Data,GetHandleId(t),0,h)
    call SaveTimerHandle(ES15_Data,k,223,t)
    call TimerStart(t,1.5,false,function EAV_Expire)
    set t=null
endfunction
