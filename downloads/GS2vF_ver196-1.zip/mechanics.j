function E191_Sanctuary takes unit h returns nothing
    local integer k=GetHandleId(h)
    if ES15_Alive(h) and LoadReal(ES15_Data,k,405)>ES15_Now() then
        call SaveReal(ES15_Data,k,23,5.0)
    else
        call RemoveSavedReal(ES15_Data,k,23)
        call RemoveSavedReal(ES15_Data,k,405)
        call GroupRemoveUnit(E191_SanctuaryUnits,h)
    endif
    call EAB_Apply(h)
endfunction
function E191_Charge takes unit h returns nothing
    local real now=ES15_Now()
    local integer k=GetHandleId(h)
    if ES15_Trait(h,5) and now>=LoadReal(ES15_Data,k,401) then
        call SaveReal(ES15_Data,k,400,now+5.0)
    endif
endfunction
function E191_Hit takes unit h, unit v returns nothing
    local integer k=GetHandleId(h)
    local real now=ES15_Now()
    local real damage
    if GetUnitTypeId(h)=='HE15' and ES15_Alive(h) and not IsUnitIllusion(h) and ES15_Trait(h,5) and BlzGetEventIsAttack() and GetEventDamage()>0.0 and IsUnitEnemy(v,GetOwningPlayer(h)) and not IsUnitType(v,UNIT_TYPE_STRUCTURE) and LoadReal(ES15_Data,k,400)>now then
        // Consume before secondary damage: cannot recurse or proc on spells.
        call RemoveSavedReal(ES15_Data,k,400)
        call SaveReal(ES15_Data,k,401,now+4.0)
        set damage=RMaxBJ(0.0,BlzGetUnitArmor(h))*3.0
        if damage>0.0 then
            call UnitDamageTarget(h,v,damage,false,false,ATTACK_TYPE_NORMAL,DAMAGE_TYPE_MAGIC,WEAPON_TYPE_WHOKNOWS)
        endif
    endif
endfunction
function E191_Passive takes unit h returns nothing
    local integer k=GetHandleId(h)
    local real now=ES15_Now()
    if not ES15_Alive(h) then
        call RemoveSavedReal(ES15_Data,k,400)
        call RemoveSavedReal(ES15_Data,k,401)
        call RemoveSavedReal(ES15_Data,k,402)
    elseif GetUnitAbilityLevel(h,'AE1e')>0 then
        if not HaveSavedReal(ES15_Data,k,402) then
            call SaveReal(ES15_Data,k,402,now+8.0)
        elseif now>=LoadReal(ES15_Data,k,402) then
            call ES15_Stacks(h,LoadInteger(ES15_Data,k,1)+1)
            call SaveReal(ES15_Data,k,402,now+8.0)
        endif
    else
        call RemoveSavedReal(ES15_Data,k,402)
    endif
endfunction
function E191_StackUI takes integer i, unit h returns nothing
    local integer k=-1000-i
    local texttag tag=LoadTextTagHandle(ES15_Data,k,410)
    local integer n
    local integer cap=10
    local integer value
    if GetUnitTypeId(h)!='HE15' or not ES15_Alive(h) or GetUnitAbilityLevel(h,'AE1e')==0 then
        if tag!=null then
            call DestroyTextTag(tag)
            call RemoveSavedHandle(ES15_Data,k,410)
            call RemoveSavedInteger(ES15_Data,k,411)
        endif
    else
        if ES15_Trait(h,3) then
            set cap=12
        endif
        set n=LoadInteger(ES15_Data,GetHandleId(h),1)
        set value=cap*100+n
        if tag==null then
            set tag=CreateTextTag()
            call SaveTextTagHandle(ES15_Data,k,410,tag)
            call SetTextTagPermanent(tag,true)
            call SetTextTagColor(tag,215,195,135,255)
        endif
        if not HaveSavedInteger(ES15_Data,k,411) or LoadInteger(ES15_Data,k,411)!=value then
            call SetTextTagText(tag,"석갑 "+I2S(n)+"/"+I2S(cap),0.018)
            call SaveInteger(ES15_Data,k,411,value)
        endif
        call SetTextTagPosUnit(tag,h,165.0)
        // UI visibility only; no local values enter combat calculations.
        call SetTextTagVisibility(tag,GetLocalPlayer()==GetOwningPlayer(h))
    endif
    set tag=null
endfunction
function E191_TickSanctuary takes nothing returns nothing
    local integer i=BlzGroupGetSize(E191_SanctuaryUnits)-1
    local unit h
    loop
        exitwhen i<0
        set h=BlzGroupUnitAt(E191_SanctuaryUnits,i)
        call E191_Sanctuary(h)
        set i=i-1
    endloop
    set h=null
endfunction
