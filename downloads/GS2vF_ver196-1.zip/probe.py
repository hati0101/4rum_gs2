from pathlib import Path
import sys,unittest,importlib.util,json,math
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'tools'))
from gs2_harness.core import inventory,script_parts
import objdata
spec=importlib.util.spec_from_file_location('avatar196',ROOT/'reviews/ver196-avatar/probe.py');avatar=importlib.util.module_from_spec(spec);spec.loader.exec_module(avatar)
raw=avatar.raw;compilefn=avatar.raw_compile
def precompile(body,ns):
 for n in ['E191_Sanctuary','E191_Charge','E191_Hit','E191_Passive','E191_StackUI','E191_TickSanctuary','GetHeroStr']:ns.setdefault(n,lambda *a:0)
 ns.setdefault('E191_SanctuaryUnits',[])
 return compilefn(body,ns)
avatar.raw_compile=precompile
class Model(avatar.Model):
 def __init__(self,functions):
  super().__init__(functions);self.attack=True;self.tags={};self.tagid=0;ns=self.ns
  def texttag():self.tagid+=1;self.tags[self.tagid]={};return self.tagid
  ns.update({'I2S':lambda v:str(v),'E191_SanctuaryUnits':[],'HaveSavedReal':lambda t,k,n:(k,n) in self.data,'GetHeroStr':lambda h,b:self.units[h].get('str',100),'BlzGetUnitArmor':lambda h:self.units[h]['armor'],'BlzGetEventIsAttack':lambda:self.attack,
   'LoadTextTagHandle':lambda t,k,n:self.data.get((k,n)),'SaveTextTagHandle':lambda t,k,n,v:self.data.update({(k,n):v}),'RemoveSavedInteger':lambda t,k,n:self.data.pop((k,n),None),
   'HaveSavedInteger':lambda t,k,n:(k,n) in self.data,'CreateTextTag':texttag,'DestroyTextTag':lambda t:self.tags.pop(t,None),'SetTextTagText':lambda t,s,h:self.tags[t].update(text=s),'SetTextTagPermanent':lambda *a:None,'SetTextTagColor':lambda *a:None,'SetTextTagPosUnit':lambda t,h,z:self.tags[t].update(hero=h),'SetTextTagVisibility':lambda t,v:self.tags[t].update(visible=v),'GetLocalPlayer':lambda:1})
  for n in ['E191_Sanctuary','E191_Charge','E191_Hit','E191_Passive','E191_StackUI','E191_TickSanctuary']:ns[n]=lambda *a:None
  for n in ['E191_Sanctuary','E191_Charge','E191_Hit','E191_Passive','E191_StackUI','E191_TickSanctuary']:compilefn(functions[n],ns)
 def auto(self):self.ns['E191_Passive'](1)
 def charge(self):self.ns['E191_Charge'](1)
class Cases(unittest.TestCase):
 f=None;a=None;q=None;before=None;after=None
 def model(self):return Model(self.f)
 def test_passive_first_charge_exactly_eight_seconds(self):
  m=self.model();m.auto();m.time=17.99;m.auto();self.assertEqual(m.data.get((1,1),0),0);m.time=18.;m.auto();self.assertEqual(m.data[1,1],1);m.auto();self.assertEqual(m.data[1,1],1)
 def test_passive_requires_e_learned(self):
  m=self.model();m.units[1]['abilities'][raw('AE1e')]=0;m.auto();m.time+=50;m.auto();self.assertNotIn((1,402),m.data);self.assertEqual(m.data.get((1,1),0),0)
 def test_no_decay_after_long_peace(self):
  m=self.model();m.stacks(8);m.time=100;m.run('Tick');self.assertGreaterEqual(m.data[1,1],8)
 def test_auto_cap_ten_and_trait_twelve(self):
  for trait,cap in [(False,10),(True,12)]:
   m=self.model();m.trait(3,trait);m.stacks(cap);m.auto();m.time+=8;m.auto();self.assertEqual(m.data[1,1],cap)
 def test_death_resets_charge_timer_and_fist(self):
  m=self.model();m.auto();m.trait(5);m.charge();m.units[1]['hp']=0;m.run('Tick');self.assertEqual(m.data[1,1],0);self.assertNotIn((1,400),m.data);self.assertNotIn((1,402),m.data);m.units[1]['hp']=500;m.time=30;m.auto();self.assertEqual(m.data[1,402],38)
 def test_q_trait_fifty_percent_strength_without_stacks(self):
  for trait,expected in [(False,290),(True,340)]:
   m=self.model();m.trait(1,trait);m.run('Q',1,100,0,4);self.assertEqual(m.damage[0][2],expected)
 def test_q_trait_strength_and_existing_stack_damage(self):
  m=self.model();m.trait(1);m.stacks(10);m.run('Q',1,100,0,4);self.assertEqual(m.damage[0][2],460);self.assertEqual(m.data[1,1],5)
 def test_q_trait_applies_to_each_enemy_not_ally(self):
  m=self.model();m.trait(1);m.hero(3,'Hpal',2,200,10);m.hero(4,'Hpal',1,100,0);m.run('Q',1,100,0,4);self.assertEqual({v for h,v,d in m.damage},{2,3});self.assertTrue(all(d==340 for h,v,d in m.damage))
 def test_q_range_375_and_cone_90(self):
  m=self.model();m.units[2]['x']=374;m.hero(3,'Hpal',2,376,0);m.hero(4,'Hpal',2,10,100);m.run('Q',1,100,0,4);self.assertEqual([v for h,v,d in m.damage],[2])
 def test_q_old_heal_trait_removed(self):
  m=self.model();m.trait(5);m.stacks(10);m.run('Q',1,100,0,4);self.assertEqual(m.units[1]['hp'],500);self.assertEqual(m.units[1]['mana'],0)
 def test_fist_requires_trait_and_real_attack(self):
  m=self.model();m.charge();self.assertNotIn((1,400),m.data);m.trait(5);m.charge();m.attack=False;m.hit(source=1,target=2);self.assertFalse(m.damage);self.assertIn((1,400),m.data)
 def test_fist_current_armor_times_three_once(self):
  m=self.model();m.trait(5);m.charge();m.units[1]['armor']=20;m.hit(source=1,target=2);self.assertEqual(m.damage,[(1,2,60)]);m.hit(source=1,target=2);self.assertEqual(len(m.damage),1);self.assertNotIn((1,400),m.data)
 def test_fist_uses_armor_at_hit_not_cast(self):
  m=self.model();m.trait(5);m.units[1]['armor']=30;m.charge();m.units[1]['armor']=10;m.hit(source=1,target=2);self.assertEqual(m.damage[0][2],30)
 def test_fist_five_second_expiry(self):
  m=self.model();m.trait(5);m.charge();m.time+=5;m.hit(source=1,target=2);self.assertFalse(m.damage)
 def test_fist_four_second_proc_cooldown(self):
  m=self.model();m.trait(5);m.charge();m.hit(source=1,target=2);m.time+=3.99;m.charge();self.assertNotIn((1,400),m.data);m.time+=.01;m.charge();self.assertEqual(m.data[1,400],19)
 def test_fist_recasts_refresh_single_charge(self):
  m=self.model();m.trait(5);m.charge();m.time+=2;m.charge();self.assertEqual(m.data[1,400],17);m.hit(source=1,target=2);m.hit(source=1,target=2);self.assertEqual(len(m.damage),1)
 def test_fist_negative_armor_never_heals(self):
  m=self.model();m.trait(5);m.charge();m.units[1]['armor']=-10;m.hit(source=1,target=2);self.assertFalse(m.damage);self.assertNotIn((1,400),m.data)
 def test_fist_does_not_proc_on_allies_structures_illusions(self):
  for kind in ['ally','structure','illusion']:
   m=self.model();m.trait(5);m.charge()
   if kind=='ally':m.units[2]['owner']=1
   if kind=='structure':m.units[2]['structure']=True
   if kind=='illusion':m.units[1]['illusion']=True
   m.hit(source=1,target=2);self.assertFalse(m.damage)
 def test_w_charges_fist_without_changing_base_w(self):
  m=self.model();m.trait(5);m.cast('w');self.assertEqual(m.data[1,400],15);self.assertEqual(m.data[1,10],15);self.assertEqual(m.data[1,1],3)
 def test_sanctuary_grants_plus_five_to_self_and_ally(self):
  m=self.model();m.trait(4);m.hero(3,'Hpal',1,100,0);m.stacks(10);m.cast('r');self.assertEqual(m.data[1,23],5);self.assertEqual(m.data[3,23],5);self.assertNotIn((2,23),m.data);self.assertEqual(m.data[1,20],500);self.assertEqual(m.data[3,20],500)
 def test_sanctuary_survives_shield_break_and_expires_ten(self):
  m=self.model();m.trait(4);m.cast('r');m.hit(d=400);self.assertNotIn((1,20),m.data);self.assertEqual(m.data[1,23],5);m.time=19.99;m.ns['E191_TickSanctuary']();self.assertEqual(m.data[1,23],5);m.time=20;m.ns['E191_TickSanctuary']();self.assertNotIn((1,23),m.data);self.assertFalse(m.ns['E191_SanctuaryUnits'])
 def test_sanctuary_death_cleanup(self):
  m=self.model();m.trait(4);m.cast('r');m.units[1]['hp']=0;m.ns['E191_TickSanctuary']();self.assertNotIn((1,23),m.data)
 def test_sanctuary_no_trait_no_armor(self):
  m=self.model();m.cast('r');self.assertEqual(m.data.get((1,23),0),0);self.assertFalse(m.ns['E191_SanctuaryUnits'])
 def test_sanctuary_recast_refreshes_not_stacks(self):
  m=self.model();m.trait(4);m.cast('r');m.time=15;m.cast('r');self.assertEqual(m.data[1,23],5);self.assertEqual(m.data[1,405],25)
 def test_stack_ui_counts_cap_owner_visibility_and_cleanup(self):
  m=self.model();m.stacks(7);m.ns['E191_StackUI'](1,1);tag=m.data[-1001,410];self.assertEqual(m.tags[tag]['text'],'석갑 7/10');m.trait(3);m.ns['E191_StackUI'](1,1);self.assertEqual(m.tags[tag]['text'],'석갑 7/12');m.ns['GetLocalPlayer']=lambda:2;m.ns['E191_StackUI'](1,1);self.assertFalse(m.tags[tag]['visible']);m.units[1]['hp']=0;m.ns['E191_StackUI'](1,1);self.assertFalse(m.tags)
 def test_objects_only_earth_tooltips_and_five_traits_changed(self):
  for ext,allowed in [('w3a',{'AE1q','AE1w','AE1e','AE1r'}),('w3q',{'RE11','RE12','RE13','RE14','RE15'})]:
   for oid in self.before[ext]:
    if oid not in allowed:self.assertEqual(self.before[ext][oid],self.after[ext][oid],oid)
 def test_w_and_r_base_numeric_fields_preserved(self):
  for aid in ['AE1w','AE1r']:
   for k,v in self.before['w3a'][aid].items():
    if not isinstance(v,str):self.assertEqual(v,self.a[aid][k],(aid,k))
 def test_trait_names_icons_completed_and_hotkeys(self):
  names=['깎아낸 바위','깊은 뿌리','겹겹의 암반','대지의 성역','돌주먹']
  for i,name in enumerate(names,1):
   o=self.q['RE1'+str(i)];self.assertEqual(o['gtp11'],name);self.assertIn('습득 완료',o['gtp12']);self.assertTrue(o['gar11'].endswith('.blp'));self.assertEqual(o['ghk11'],self.before['w3q']['RE1'+str(i)]['ghk11'])
 def test_version_minimap_and_range_ui(self):
  self.assertIn('196-1',self.f['config']);self.assertIn('return 375.0',self.f['GSRI_Range']);self.assertEqual(self.f['GSTI_Ready'].count('CreateMinimapIconOnUnit'),2)
 def test_unchanged_other_heroes_items_resources(self):
  for n in self.oldfiles:
   if n not in ['war3map.j','war3map.wct','war3map.w3i','war3map.w3a','war3map.w3q','(attributes)']:self.assertEqual(self.oldfiles[n],self.files[n],n)
# Re-run the retained W immunity lifecycle against this candidate as well.
avatar.Model=Model
for name in ['test_no_trait_keeps_normal_w_without_magic_immunity','test_trait_cleanses_bottle_and_gives_immunity_for_one_point_five','test_base_w_still_lasts_five_seconds','test_recast_replaces_owned_timer_without_stacking','test_stale_expiry_never_ends_new_cast','test_death_or_form_change_removes_only_owned_immunity','test_external_immunity_positive_buffs_and_inventory_preserved','test_failed_ability_add_never_claims_active_or_purges','test_no_avatar_health_attack_or_defense_bonus','test_removed_hero_expiry_still_cleans_owned_timer']:
 def retained(self,n=name):
  case=avatar.Cases(n);case.functions=self.f;case.abilities=self.a;getattr(case,n)()
 setattr(Cases,'test_retained_'+name[5:],retained)
if __name__=='__main__':
 arc,files=inventory(sys.argv[1]);base,oldfiles=inventory('/workspace/artifacts/gs2-ver196-release/GS2vF_ver196.w3x');Cases.f=script_parts(files['war3map.j'])[0];Cases.files=files;Cases.oldfiles=oldfiles
 Cases.before={e:objdata.load_objects(base,'war3map.'+e) for e in ['w3a','w3q']};Cases.after={e:objdata.load_objects(arc,'war3map.'+e) for e in ['w3a','w3q']};Cases.a=Cases.after['w3a'];Cases.q=Cases.after['w3q']
 unittest.main(argv=[sys.argv[0]],verbosity=2)
