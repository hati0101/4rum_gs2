from pathlib import Path
import sys,re,struct,json,difflib,importlib.util
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'tools'))
import objdata
from gs2_harness.core import inventory,backup,digest,script_parts,impact,integrity,wct_blocks,compare
spec=importlib.util.spec_from_file_location('prev196',ROOT/'reviews/ver196-avatar/build.py');prev=importlib.util.module_from_spec(spec);spec.loader.exec_module(prev)
once=prev.once;update=prev.prior.update_object
HERE=Path(__file__).resolve().parent
SOURCE=Path('/workspace/artifacts/gs2-ver196-release/GS2vF_ver196.w3x');SHA='c46d905651eea7c773061822dccf03ac705d9958542ac2c3bbdabf14abe3174a'
REVIEWED=['ES15_Q','ES16_QTick','ES15_Damage','ES15_Spell','ES15_Tick','ES15_ShieldEnd','EAB_ShieldArmor','ES15_Init','ETW_TooltipRefresh','GSTI_Ready','GSRI_Range','ES15_Stacks']
def version(s):
 return re.sub(r'"(?:[^"\\]|\\.)*"',lambda m:re.sub(r'(?<!\d)196(?![\d-])','196-1',m[0]),s)
def patch(s):
 f,_=script_parts(s.encode());changes={}
 if 'ES15_Q' in f:
  fn=f['ES15_Q'].replace('325.0','375.0')
  fn=once(fn,'        set slowRank=lv+4','        set damage=damage+I2R(GetHeroStr(h,true))*0.5\n        set slowRank=lv+4')
  start=fn.index('    if hit and spent>0 and ES15_Trait(h,5) then');end=fn.index('    call DestroyGroup(g)',start)
  changes['ES15_Q']=fn[:start]+fn[end:]
 if 'ES16_QTick' in f:changes['ES16_QTick']=f['ES16_QTick'].replace('28.5*I2R(step)','33.5*I2R(step)')
 if 'ES15_Stacks' in f:changes['ES15_Stacks']=f['ES15_Stacks']+'\n\n'+(HERE/'mechanics.j').read_text().strip()
 if 'ES15_Damage' in f:changes['ES15_Damage']=once(f['ES15_Damage'],'    set v=null\n    set s=null\nendfunction','    call E191_Hit(s,v)\n    set v=null\n    set s=null\nendfunction')
 if 'ES15_Spell' in f:
  fn=once(f['ES15_Spell'],"    if id=='AE1q' then","    if id=='AE1q' or id=='AE1w' or id=='AE1r' then\n        call E191_Charge(h)\n    endif\n    if id=='AE1q' then")
  changes['ES15_Spell']=once(fn,'                call ES15_Shield(h,v,','                if ES15_Trait(h,4) then\n                    call SaveReal(ES15_Data,GetHandleId(v),405,now+10.0)\n                    call GroupAddUnit(E191_SanctuaryUnits,v)\n                    call E191_Sanctuary(v)\n                endif\n                call ES15_Shield(h,v,')
 if 'ES15_ShieldEnd' in f:
  changes['ES15_ShieldEnd']=once(f['ES15_ShieldEnd'],'    call RemoveSavedReal(ES15_Data,k,23)\n    call EAB_Apply(h)','    call EAB_ShieldArmor(h)')
 if 'EAB_ShieldArmor' in f:
  changes['EAB_ShieldArmor']='''function EAB_ShieldArmor takes unit h returns nothing
    local integer k=GetHandleId(h)
    local real value=0.0
    if ES15_Alive(h) and LoadReal(ES15_Data,k,405)>ES15_Now() then
        set value=5.0
    endif
    call SaveReal(ES15_Data,k,23,value)
    call EAB_Apply(h)
endfunction'''
 if 'ES15_Tick' in f:
  fn=once(f['ES15_Tick'],'        call EAV_Tick(h)','        call EAV_Tick(h)\n        call E191_StackUI(i,h)')
  fn=once(fn,'            if not ES15_Alive(h) then','            call E191_Passive(h)\n            if not ES15_Alive(h) then')
  start=fn.index('                if n>0 and now>=LoadReal(ES15_Data,k,4)+6.0');end=fn.index('                call ES15_Armor(h)',start)
  fn=fn[:start]+fn[end:]
  changes['ES15_Tick']=once(fn,'    set j=BlzGroupGetSize(ES15_Shields)-1','    call E191_TickSanctuary()\n    set j=BlzGroupGetSize(ES15_Shields)-1')
 if 'ES15_Init' in f:changes['ES15_Init']=once(f['ES15_Init'],'    set ES15_Shields=CreateGroup()','    set ES15_Shields=CreateGroup()\n    set E191_SanctuaryUnits=CreateGroup()')
 if 'GSTI_Ready' in f:
  fn=once(f['GSTI_Ready'],'    set GSTI_Shops[1]=CreateUnit', '    set GSTI_Shops[1]=CreateUnit')
  marker='    call RemoveItemFromStock(GSTI_Shops[0],\'IT00\')'
  changes['GSTI_Ready']=once(fn,marker,'    call SetMinimapIconOrphanDestroy(CreateMinimapIconOnUnit(GSTI_Shops[0],255,215,80,"UI\\\\MiniMap\\\\MiniMap-NeutralBuilding.blp",FOG_OF_WAR_MASKED),true)\n    call SetMinimapIconOrphanDestroy(CreateMinimapIconOnUnit(GSTI_Shops[1],255,215,80,"UI\\\\MiniMap\\\\MiniMap-NeutralBuilding.blp",FOG_OF_WAR_MASKED),true)\n'+marker)
 if 'GSRI_Range' in f:changes['GSRI_Range']=once(f['GSRI_Range'],'            return 325.0','            return 375.0')
 if 'ETW_TooltipRefresh' in f:
  fn=f['ETW_TooltipRefresh'].replace('전방 325','전방 375').replace('영웅과 피해 교환 없이 6초 후 초당 1개 감소. 사망 시 초기화.','생존 중 8초마다 +1. 자연 감소 없음. 사망 시 초기화.')
  fn=fn.replace('석갑 소모 시 감속 +10%p · 지속 +0.5초','총 힘 50% 추가 마법 피해 · 석갑 소모 시 감속 강화')
  fn=fn.replace('보호막 대상 방어력 +3 · 보호막 소진/종료 시 해제','궁 시전 시 자신·범위 내 아군 영웅 방어력 +5 · 보호막과 별개로 10초')
  fn=fn.replace('지맥 순환','돌주먹').replace('적 영웅 적중 시 소모 석갑당 체력8·마나3 회복 · 시전당 1회','스킬 후 다음 평타: 적중 시 총 방어력×3 마법 피해 · 충전 5초 / 발동 쿨 4초')
  # Passive influences all active abilities, not just Q.
  fn=fn.replace("        call GS2TT_Append(p,'AE1q',4,\"돌주먹\"", "        call GS2TT_Append(p,'AE1w',4,\"돌주먹\",\"스킬 후 다음 평타 강화 · 충전 5초 / 발동 쿨 4초\",true)\n        call GS2TT_Append(p,'AE1r',3,\"돌주먹\",\"스킬 후 다음 평타 강화 · 충전 5초 / 발동 쿨 4초\",true)\n        call GS2TT_Append(p,'AE1q',4,\"돌주먹\"")
  changes['ETW_TooltipRefresh']=fn
 for n,new in changes.items():s=once(s,f[n],new)
 if 'endglobals' in s:s=s.replace('endglobals','    group E191_SanctuaryUnits = null\nendglobals',1)
 return version(s)
def abilities(data):
 a=objdata.load_objects(prev.prior.w3x.Archive(str(SOURCE)),'war3map.w3a') if False else None
 arc,files=inventory(SOURCE);a=objdata.load_objects(arc,'war3map.w3a')
 for aid in ['AE1q','AE1w','AE1e','AE1r']:
  o=a[aid];updates={}
  for key,val in o.items():
   if not isinstance(val,str):continue
   if key=='arut' or key.startswith('aub1'):
    new=val.replace('전방 325','전방 375').replace('영웅과 피해 교환 없이 6초 후 초당 1개 감소. 사망 시 초기화.','생존 중 8초마다 +1. 자연 감소 없음. 사망 시 초기화.')
    updates[(key[:4],0 if key=='arut' else int(key[4:]))]=new
  data=update(data,aid,True,updates)
 return data
def upgrades(data):
 names=['깎아낸 바위','깊은 뿌리','겹겹의 암반','대지의 성역','돌주먹']
 desc=['쇄암격에 총 힘의 50%만큼 마법 피해가 추가됩니다. 석갑 소모 시 이동 감속 +10%p, 지속 +0.5초.','산의 전진 사용 시 해로운 마법 효과를 해제하고 1.5초간 마법 면역이 됩니다.','석갑 최대 보유량이 10개에서 12개로 증가합니다. 개당 방어력은 유지됩니다.','궁 시전 시 자신과 범위 내 아군 영웅의 보너스 방어력이 10초간 5 증가합니다. 보호막이 깨져도 유지됩니다.','스킬 사용 후 5초 내 다음 평타에 적중 시 총 방어력의 3배만큼 마법 피해가 추가됩니다. 중첩 불가. 발동 후 쿨 4초.']
 icons=['BTNFragmentationBombs.blp','BTNAvatar.blp','BTNSpikedCarapace.blp','BTNDevotion.blp','BTNStoneForm.blp']
 for i in range(5):
  d={}
  for lv in [1,2]:
   d['gtp1',lv]=names[i]+(' — 습득 완료' if lv==2 else '')
   d['gub1',lv]=desc[i]+('|n|cff80ff80습득 완료|r' if lv==2 else '')
   d['gar1',lv]='ReplaceableTextures\\CommandButtons\\'+icons[i]
  data=update(data,'RE1'+str(i+1),True,d)
 return data
def build(out):
 out=Path(out)
 if out.exists():raise ValueError('fresh directory required')
 saved=backup(SOURCE,out/'backups');arc,old=inventory(SOURCE);assert digest(arc.data)==SHA
 before=impact(old['war3map.j'],REVIEWED)
 script=patch(old['war3map.j'].decode()).encode()
 data=old['war3map.wct'];p=data.index(b'\0',8)+1;wct=bytearray(data[:p])
 while p<len(data):
  n=struct.unpack_from('<I',data,p)[0];p+=4;chunk=data[p:p+n];p+=n
  if n:chunk=patch(chunk[:-1].decode()).encode()+b'\0'
  wct+=struct.pack('<I',len(chunk))+chunk
 data=old['war3map.w3i'];end=data.index(b'\0',28);assert data[28:end].decode()=='가디언 스피리츠 II 196'
 repl={'war3map.j':script,'war3map.wct':bytes(wct),'war3map.w3i':data[:28]+'가디언 스피리츠 II 196-1'.encode()+data[end:],'war3map.w3a':abilities(old['war3map.w3a']),'war3map.w3q':upgrades(old['war3map.w3q'])}
 f0,g0=script_parts(old['war3map.j']);f1,g1=script_parts(script);changed=sorted(n for n in f0.keys()|f1.keys() if f0.get(n)!=f1.get(n))
 for n in changed:
  if n in REVIEWED or n.startswith('E191_'):continue
  assert version(f0[n])==f1[n],n
 editor={}
 for block in wct_blocks(bytes(wct)):editor.update(script_parts(block)[0])
 for n in changed:
  if n in editor and n!='GSRI_Range':assert f1[n]==editor[n],n
 temp=out/'uncompacted.w3x';arc.save_with_replacements(str(temp),repl);candidate=out/'GS2vF_ver196-1.w3x';removed=prev.prior.stability.compact(temp,candidate);temp.unlink()
 b,new=inventory(candidate);files=sorted(n for n in old if old[n]!=new[n]);assert set(files)==set(repl)|{'(attributes)'};assert old.keys()==new.keys()
 for n in old:
  if n not in files:assert old[n]==new[n]
 scope0=impact(old['war3map.j'],changed);scope1=impact(script,changed)
 policy={'source_sha256':SHA,'files':{n:digest(new[n]) for n in files},'functions':changed,'reviewed_callers':{n:sorted(set(scope0['transitive_callers'].get(n,[]))|set(scope1['transitive_callers'].get(n,[]))) for n in changed},'manual_dependency_review':'reviews/ver196-1/README.md; HE15-only combat changes; W and R base values preserved. Independent sanctuary group/deadline; hashtable children400-411 reserved for196-1. E191_Hit consumes before secondary damage; no attack event recursion. Owner-only text tag visibility never used in combat. GSTI minimap icons display only. GSRI_Range changes HE15 Q branch only.','dynamic_call_review':'No added repeating timer or new event subscribers. Existing ES15 Tick and Spell/Damage hooks used.','acknowledged_source_crc_mismatches':integrity(arc,old)['crc_mismatches'],'reviewed_nonfunction_text':{'before_sha256':digest(g0.encode()),'after_sha256':digest(g1.encode()),'reason':'One new sanctuary group; initialized with Earth subsystem; version labels.'},'wct_outside_functions':{}}
 for i,(x,y) in enumerate(zip(wct_blocks(old['war3map.wct']),wct_blocks(bytes(wct)))):
  _,xx=script_parts(x);_,yy=script_parts(y)
  if xx!=yy:policy['wct_outside_functions'][str(i)]={'before_sha256':digest(xx.encode()),'after_sha256':digest(yy.encode()),'reason':'Sanctuary group global/version label.'}
 (out/'policy.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n');(out/'candidate.j').write_bytes(script)
 (out/'script.diff').write_text(''.join(difflib.unified_diff(old['war3map.j'].decode().splitlines(True),script.decode().splitlines(True),fromfile='196',tofile='196-1')))
 gate=compare(SOURCE,candidate,policy,out/'gate','/workspace/gs2-toolchain/pjass/pjass','/workspace/gs2-toolchain/headers/common.j','/workspace/gs2-toolchain/headers/blizzard.j')
 report={'version':'196-1','source_sha256':SHA,'backup':saved,'candidate_sha256':digest(b.data),'candidate_bytes':len(b.data),'active_files':len(new),'changed_files':files,'changed_functions':changed,'before_patch_caller_review':before,'compaction_bytes_removed':removed,'acceptance':gate['status'],'errors':gate['errors'],'actual_game_tests':0,'status':'TEST_CANDIDATE_NOT_GAME_VALIDATED'}
 (out/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 if gate['status']!='PASS':raise ValueError('adoption blocked '+str(gate['errors']))
 return report
if __name__=='__main__':print(json.dumps(build(sys.argv[1]),ensure_ascii=False,indent=2))
